<?php

require "connect.php";
require "suggestion.class.php";


// Converting the IP to a number. This is a more effective way
// to store it in the database:

$ip	= sprintf('%u',ip2long($_SERVER['REMOTE_ADDR']));


// The following query uses a left join to select
// all the suggestions and in the same time determine
// whether the user has voted on them.

$result = $mysqli->query("
	SELECT s.*, if (v.ip IS NULL,0,1) AS have_voted
	FROM suggestions AS s
	LEFT JOIN suggestions_votes AS v
	ON(
		s.id = v.suggestion_id
		AND v.day = CURRENT_DATE
		AND v.ip = $ip
	)
	ORDER BY s.rating DESC, s.id DESC
");

$str = '';

if(!$mysqli->error)
{
	// Generating the UL
	
	$str = '<ul class="suggestions">';
	
	// Using MySQLi's fetch_object method to create a new
	// object and populate it with the columns of the result query:
	
	while($suggestion = $result->fetch_object('Suggestion')){
		
		$str.= $suggestion;	// Using the __toString() magic method.
		
	}
	
	$str .='</ul>';
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Suggestions TODO</title>

<link rel="stylesheet" type="text/css" href="styles.css" />
<style>
/*
 * Copyright (c) 2012-2013 Thibaut Courouble
 * http://www.cssflow.com
 *
 * Licensed under the MIT License:
 * http://www.opensource.org/licenses/mit-license.php
 */


.progress {
  height: 20px;
  background: #403e3c;
  border-left: 1px solid transparent;
  border-right: 1px solid transparent;
  border-radius: 10px;
  margin: 5px;
}
.progress > span {
  position: relative;
  float: left;
  margin: 0 -1px;
  min-width: 30px;
  height: 18px;
  line-height: 16px;
  text-align: right;
  background: #cccccc;
  border: 1px solid;
  border-color: #bfbfbf #b3b3b3 #9e9e9e;
  border-radius: 10px;
  background-image: -webkit-linear-gradient(top, #f0f0f0, #dbdbdb 70%, #cccccc);
  background-image: -moz-linear-gradient(top, #f0f0f0, #dbdbdb 70%, #cccccc);
  background-image: -o-linear-gradient(top, #f0f0f0, #dbdbdb 70%, #cccccc);
  background-image: linear-gradient(to bottom, #f0f0f0, #dbdbdb 70%, #cccccc);
  -webkit-box-shadow: inset 0 1px rgba(255, 255, 255, 0.3), 0 1px 2px rgba(0, 0, 0, 0.2);
  box-shadow: inset 0 1px rgba(255, 255, 255, 0.3), 0 1px 2px rgba(0, 0, 0, 0.2);
}
.progress > span > span {
  padding: 0 8px;
  font-size: 11px;
  font-weight: bold;
  color: #404040;
  color: rgba(0, 0, 0, 0.7);
  text-shadow: 0 1px rgba(255, 255, 255, 0.4);
}
.progress > span:before {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 1;
  height: 18px;
  background: url("../img/progress.png") 0 0 repeat-x;
  border-radius: 10px;
}
.progress .green {
  background: #85c440;
  border-color: #78b337 #6ba031 #568128;
  background-image: -webkit-linear-gradient(top, #b7dc8e, #99ce5f 70%, #85c440);
  background-image: -moz-linear-gradient(top, #b7dc8e, #99ce5f 70%, #85c440);
  background-image: -o-linear-gradient(top, #b7dc8e, #99ce5f 70%, #85c440);
  background-image: linear-gradient(to bottom, #b7dc8e, #99ce5f 70%, #85c440);
}
.progress .red {
  background: #db3a27;
  border-color: #c73321 #b12d1e #8e2418;
  background-image: -webkit-linear-gradient(top, #ea8a7e, #e15a4a 70%, #db3a27);
  background-image: -moz-linear-gradient(top, #ea8a7e, #e15a4a 70%, #db3a27);
  background-image: -o-linear-gradient(top, #ea8a7e, #e15a4a 70%, #db3a27);
  background-image: linear-gradient(to bottom, #ea8a7e, #e15a4a 70%, #db3a27);
}
.progress .orange {
  background: #f2b63c;
  border-color: #f0ad24 #eba310 #c5880d;
  background-image: -webkit-linear-gradient(top, #f8da9c, #f5c462 70%, #f2b63c);
  background-image: -moz-linear-gradient(top, #f8da9c, #f5c462 70%, #f2b63c);
  background-image: -o-linear-gradient(top, #f8da9c, #f5c462 70%, #f2b63c);
  background-image: linear-gradient(to bottom, #f8da9c, #f5c462 70%, #f2b63c);
}
.progress .blue {
  background: #5aaadb;
  border-color: #459fd6 #3094d2 #277db2;
  background-image: -webkit-linear-gradient(top, #aed5ed, #7bbbe2 70%, #5aaadb);
  background-image: -moz-linear-gradient(top, #aed5ed, #7bbbe2 70%, #5aaadb);
  background-image: -o-linear-gradient(top, #aed5ed, #7bbbe2 70%, #5aaadb);
  background-image: linear-gradient(to bottom, #aed5ed, #7bbbe2 70%, #5aaadb);
}	
</style>
</head>

<body>

<div id="page">

    <div id="heading" class="rounded">
    	<h1>Suggestions</h1>
		<p>Faites des suggestions pour la nouvelle version. C'est une sorte de TODO communautaire.</p>
	<br>
	<h3>Infrastructure</h3>
	<div class="progress">
      <span style="width: 10%;"><span>10%</span></span>
    </div>
	<h3>Code de base</h3>
    <div class="progress">
      <span class="blue" style="width: 20%;"><span>20%</span></span>
    </div>
	<h3>Intégration des suggestions</h3>
    <div class="progress">
      <span class="orange" style="width: 0%;"><span>0%</span></span>
    </div>
	<h3>Autres</h3>
    <div class="progress">
      <span class="red" style="width: 0%;"><span>0%</span></span>
    </div>		
    </div>

	<?php
		echo $str;
	?>
    
    <form id="suggest" action="" method="post">
        <p>
            <input type="text" id="suggestionText" class="rounded" maxlength="255" />
            <input type="submit" value="Submit" id="submitSuggestion" />
        </p>
	</form>

</div>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="script.js"></script>
</body>
</html>
